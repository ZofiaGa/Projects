"use strict";

const submitPage = document.querySelector(".submit-page");
const numberToSelect = document.querySelectorAll(".number");
const submitBtn = document.querySelector(".submit-btn");
const thankYouPage = document.querySelector(".thank-you-page");
const selectedNum = document.querySelector(".selected-num");


for (let i = 0; i < numberToSelect.length; i++)
  numberToSelect[i].addEventListener("click", function () {
    selectedNum.textContent =  'You selected ' + numberToSelect[i].textContent + ' out of 5';
  });

submitBtn.addEventListener("click", function () {    
  submitPage.classList.add("hidden");
  thankYouPage.classList.remove("hidden");
});

